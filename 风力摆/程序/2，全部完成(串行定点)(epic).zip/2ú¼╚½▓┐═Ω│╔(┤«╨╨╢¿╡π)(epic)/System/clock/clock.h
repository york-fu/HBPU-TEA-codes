#ifndef __CLOCK_H
#define __CLOCK_H 			   
#include "sys.h"  


void SystemClock_Init(void);
void delay_ms(uint16_t nms);
void delay_us(uint16_t nus);	

#endif





























